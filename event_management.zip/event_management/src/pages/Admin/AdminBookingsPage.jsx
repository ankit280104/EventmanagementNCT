import { Check, Search, Trash2, X, AlertCircle, RefreshCw } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// This would normally come from your API
const bookings = [
  {
    id: "1",
    eventTitle: "Introduction to Web Development",
    userName: "John Doe",
    userEmail: "john@example.com",
    date: "2024-03-15",
    time: "10:00 AM - 12:00 PM",
    status: "CONFIRMED",
    paymentStatus: "PAID",
    amount: 99.99,
  },
  {
    id: "2",
    eventTitle: "Advanced React Patterns",
    userName: "Jane Smith",
    userEmail: "jane@example.com",
    date: "2024-03-20",
    time: "2:00 PM - 4:00 PM",
    status: "PENDING",
    paymentStatus: "PENDING",
    amount: 149.99,
  },
  {
    id: "3",
    eventTitle: "UI/UX Design Workshop",
    userName: "Bob Wilson",
    userEmail: "bob@example.com",
    date: "2024-03-25",
    time: "1:00 PM - 3:00 PM",
    status: "CANCELLED",
    paymentStatus: "REFUNDED",
    amount: 79.99,
  },
];

const getStatusColor = (status) => {
  const statusColors = {
    CONFIRMED: "bg-green-100 text-green-800",
    PENDING: "bg-yellow-100 text-yellow-800",
    CANCELLED: "bg-red-100 text-red-800",
    COMPLETED: "bg-blue-100 text-blue-800",
  };
  return statusColors[status] || "bg-gray-100 text-gray-800";
};

const getPaymentStatusColor = (status) => {
  const statusColors = {
    PAID: "bg-green-100 text-green-800",
    PENDING: "bg-yellow-100 text-yellow-800",
    REFUNDED: "bg-purple-100 text-purple-800",
    FAILED: "bg-red-100 text-red-800",
  };
  return statusColors[status] || "bg-gray-100 text-gray-800";
};

export default function AdminBookingsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [selectedBooking, setSelectedBooking] = useState(null);

  const filteredBookings = bookings.filter((booking) => {
    const matchesSearch =
      booking.eventTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.userEmail.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "ALL" || booking.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleStatusChange = async (bookingId, newStatus) => {
    // Here you would normally make an API call to update the status
    console.log(`Updating booking ${bookingId} to status ${newStatus}`);
  };

  const BookingDetailsDialog = ({ booking }) => (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle>Booking Details</DialogTitle>
        <DialogDescription>
          Complete information about the booking
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="font-medium">Event</h4>
            <p>{booking.eventTitle}</p>
          </div>
          <div>
            <h4 className="font-medium">Date & Time</h4>
            <p>{booking.date}</p>
            <p>{booking.time}</p>
          </div>
          <div>
            <h4 className="font-medium">User</h4>
            <p>{booking.userName}</p>
            <p className="text-sm text-gray-500">{booking.userEmail}</p>
          </div>
          <div>
            <h4 className="font-medium">Payment</h4>
            <p>${booking.amount}</p>
            <Badge className={getPaymentStatusColor(booking.paymentStatus)}>
              {booking.paymentStatus}
            </Badge>
          </div>
        </div>
        <div className="flex gap-2 justify-end">
          <Button variant="outline" onClick={() => setSelectedBooking(null)}>
            Close
          </Button>
        </div>
      </div>
    </DialogContent>
  );

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Manage Bookings</h1>
        <Button onClick={() => window.location.reload()}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      <div className="flex gap-4 mb-6">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search bookings..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Statuses</SelectItem>
            <SelectItem value="CONFIRMED">Confirmed</SelectItem>
            <SelectItem value="PENDING">Pending</SelectItem>
            <SelectItem value="CANCELLED">Cancelled</SelectItem>
            <SelectItem value="COMPLETED">Completed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Event</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Date & Time</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredBookings.map((booking) => (
              <TableRow key={booking.id}>
                <TableCell className="font-medium">
                  {booking.eventTitle}
                </TableCell>
                <TableCell>
                  <div>{booking.userName}</div>
                  <div className="text-sm text-gray-500">
                    {booking.userEmail}
                  </div>
                </TableCell>
                <TableCell>
                  <div>{booking.date}</div>
                  <div className="text-sm text-gray-500">{booking.time}</div>
                </TableCell>
                <TableCell>
                  <Badge className={getStatusColor(booking.status)}>
                    {booking.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div>${booking.amount}</div>
                  <Badge
                    className={getPaymentStatusColor(booking.paymentStatus)}
                  >
                    {booking.paymentStatus}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Dialog
                      open={selectedBooking?.id === booking.id}
                      onOpenChange={() => setSelectedBooking(null)}
                    >
                      <DialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setSelectedBooking(booking)}
                        >
                          <AlertCircle className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      {selectedBooking && (
                        <BookingDetailsDialog booking={selectedBooking} />
                      )}
                    </Dialog>

                    {booking.status === "PENDING" && (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            handleStatusChange(booking.id, "CONFIRMED")
                          }
                        >
                          <Check className="h-4 w-4 text-green-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            handleStatusChange(booking.id, "CANCELLED")
                          }
                        >
                          <X className="h-4 w-4 text-red-600" />
                        </Button>
                      </>
                    )}

                    {booking.status !== "PENDING" && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() =>
                          handleStatusChange(booking.id, "CANCELLED")
                        }
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
