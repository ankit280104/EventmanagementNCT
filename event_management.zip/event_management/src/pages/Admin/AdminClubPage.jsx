import { Delete, PaintBucket, Plus, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Link } from "react-router-dom";
import { useAtom } from "jotai";
import { clubsListAtom } from "@/atom/userAtoms";

export default function AdminClubsPage() {
  const [clubs, setClubs] = useAtom(clubsListAtom);
  
  const handleDeleteClubs = async (clubId) => {
    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/clubs/${clubId}`,
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete event");
      }

      // Update the state to remove the deleted event
      setClubs((prevClubs) => prevClubs.filter((clubs) => clubs.id !== clubId));
      alert("Success: Club Deleted successfully!");
    } catch (error) {
      console.error("Error deleting event:", error);
    }
  };

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Manage Clubs</h1>
        <Button asChild>
          <Link to="/admin/clubs/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Club
          </Link>
        </Button>
      </div>

      {clubs.length === 0 ? (
        <p className="text-center text-xl text-gray-500">No clubs available.</p>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Add Events</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clubs.map((club) => (
                <TableRow key={club._id}>
                  <TableCell className="text-center">
                    {/* Add Image Cell */}
                    <img
                      src={club.image || "https://via.placeholder.com/100"} // Placeholder if no image
                      alt={club.title}
                      className="w-20 h-20 object-cover  mx-auto"
                    />
                  </TableCell>
                  <TableCell className="font-medium">{club.title}</TableCell>
                  <TableCell className="truncate max-w-xs">
                    {club.description}
                  </TableCell>
                  <TableCell>
                    <Link to={`/admin/events/${club._id}`} id="add-event-link">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Event
                    </Link>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      asChild
                      onClick={handleDeleteClubs(club._id)}
                    >
                      <Trash2 />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
