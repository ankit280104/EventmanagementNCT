import { sendEmail } from "./config/mailer.js";

const testEmail = async () => {
  try {
    const response = await sendEmail(
      "ankitkundu866@gmail.com",
      "Test Email",
      {
        eventName: "Tech Conference 2025",
        userName: "John Doe",
        eventDateTime: "March 15, 2025, 10:00 AM",
        userEmail: "tijwadev@gmail.com",
        confirmationLink: "https://example.com/confirm?event=12345",
      },
      "event.notification.ejs"
    );
    console.log("Email sent successfully:", response);
  } catch (error) {
    console.error("Error sending test email:", error);
  }
};

testEmail();
